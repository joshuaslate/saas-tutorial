module.exports = {
  'secret': 'longobnoxiouspassphrase',
  'database': 'mongodb://josh:test@ds011158.mlab.com:11158/saas-tutorial'
};
